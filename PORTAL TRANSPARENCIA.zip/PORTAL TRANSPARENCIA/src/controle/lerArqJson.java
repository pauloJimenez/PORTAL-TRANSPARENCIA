package controle;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import DAO.*;

import com.google.gson.Gson;

import modelo.*;

public class lerArqJson {
			
	despesa d;
	despesaPublica despesa;
	
    public lerArqJson(){
    	
    	
    }
	
	public void lerArqJson(String dadosJson){
		
		//conecta com o BD
		DAO dao = new DAO();				
		
		Gson gson = new Gson();
		
		//separa os dados do retorno do JSON
		String regex = "\\{.*?\\}";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(dadosJson);				
					
		while (m.find()) {
			
			d = gson.fromJson(m.group(), despesa.class);  			
			
			despesa = new despesaPublica();						
			
			despesa.setCodigoFavorecido(d.codigoFavorecido);
			despesa.setData(d.data);
			despesa.setDocumento(d.documento);
			despesa.setDocumentoResumido(d.documentoResumido);
			despesa.setEspecie(d.especie);
			despesa.setFase(d.fase);
			despesa.setFavorecido(d.favorecido);
			despesa.setFavorecidoIntermediario(d.favorecidoIntermediario);
			despesa.setLocalizadorGasto(d.localizadorGasto);
			despesa.setNomeFavorecido(d.nomeFavorecido);
			despesa.setOrgao(d.orgao);
			despesa.setOrgaoSuperior(d.orgaoSuperior);
			despesa.setSubtitulo(d.subtitulo);
			despesa.setUfFavorecido(d.ufFavorecido);
			despesa.setUg(d.ug);
			despesa.setValor(d.valor);
			
			//atualiza a despesa no BD
			dao.criadespesa(despesa);
			
	}
	
	
}

	class despesa{
		
		String codigoFavorecido;
		String data;
		String documento;
		String documentoResumido; 
		String especie; 
		String fase; 
		String favorecido;	
		String favorecidoIntermediario;
		String localizadorGasto;
		String nomeFavorecido;
		String orgao;
		String orgaoSuperior;
		String subtitulo;
		String ufFavorecido;
		String ug;
		String valor;
	}
}
