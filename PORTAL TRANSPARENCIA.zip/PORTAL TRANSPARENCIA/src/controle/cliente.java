package controle;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;



import modelo.despesaPublica;


public class cliente {

	private static int HTTP_COD_SUCESSO = 200;		
	
	public cliente(){
		
	}
	
	//executa pagina por pagina
	public boolean  executa(String unidG, String dtEm, String fase, String pagina,String gestao, despesaPublica retorno){
		
		String linha = null;

		boolean ok = false;
		
		 try {
			 
			 	lerArqJson  lerArq = new lerArqJson();
			 
			 	URL url;
			 	
			 	String url_ = "http://www.transparencia.gov.br/api-de-dados/despesas/documentos?";
			 	
			 	//monta a URL
			 	if(!unidG.equals("")){
			 		
			 		url_+= "unidadeGestora="+unidG;
			 		
			 	}
			 	if(!unidG.equals("") && !gestao.equals("")){
			 		
			 		url_+= "&gestao="+gestao;
			 		
			 	}
			 	if(unidG.equals("") && !gestao.equals("")){
			 		
			 		url_+= "gestao="+gestao;
			 		
			 	}
			 	
			        url_+= "&dataEmissao="+dtEm+"&fase="+fase+"&pagina="+pagina;
			 				 	
			 		url = new URL(url_);			 	
			 	
			 		HttpURLConnection con = (HttpURLConnection) url.openConnection();
			 		
		            if (con.getResponseCode() != HTTP_COD_SUCESSO) {
		                retorno.setRetorno("HTTP error code : "+ con.getResponseCode());
		            }
	 	                
		            BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(),"UTF-8"));		            		            		            		           
		            
		            while ((linha = br.readLine()) != null) { 
		            		
		            	if (!linha.equals("[]")){
			            	lerArq.lerArqJson(linha);
			            	ok=true;
		            	}

		             }       
		            retorno.setRetorno(con.getResponseMessage());
		            con.disconnect();
	      
	        } catch (MalformedURLException e) {
	        	retorno.setRetorno(e.toString());
	        } catch (IOException e) {
	        	retorno.setRetorno(e.toString());
	        }
		 	
		 return ok;
	}

	
		//executa no maximo 99 paginas
		public boolean  executaAll(String unidG, String dtEm, String fase, String pagina,String gestao){
			
			String linha1 = null;
         
			boolean ok = false; 
			
			 try {
				 
				 	lerArqJson  lerArq = new lerArqJson();
				 
				 	URL url1;
				 	
				 	String url_ = "http://www.transparencia.gov.br/api-de-dados/despesas/documentos?";
				 	
				 	//monta a URL
				 	if(!unidG.equals("")){
				 		
				 		url_+= "unidadeGestora="+unidG;
				 		
				 	}
				 	if(!unidG.equals("") && !gestao.equals("")){
				 		
				 		url_+= "&gestao="+gestao;
				 		
				 	}
				 	if(unidG.equals("") && !gestao.equals("")){
				 		
				 		url_+= "gestao="+gestao;
				 		
				 	}
				 	
				        url_+= "&dataEmissao="+dtEm+"&fase="+fase+"&pagina="+pagina;
				 				 	
				 		url1 = new URL(url_);			 	
				 	
				 		HttpURLConnection con = (HttpURLConnection) url1.openConnection();		 				 		
				 		
			            if (con.getResponseCode() != HTTP_COD_SUCESSO) {
			                throw new RuntimeException("HTTP error code : "+ con.getResponseCode());
			            }
		 
		                
			            BufferedReader br1 = new BufferedReader(new InputStreamReader(con.getInputStream(),"UTF-8"));
			           
			         			            	
			            while ((linha1 = br1.readLine()) != null ) {   	              	                
			            	if (!linha1.equals("[]")){
				            	lerArq.lerArqJson(linha1);
				            	ok=true;
			            	}
			            } 
			            			           
			            con.disconnect();
		 			            
			            
		        } catch (MalformedURLException e) {
		            e.printStackTrace();
		        } catch (IOException e) {
		            e.printStackTrace();
		        }

			 
			 return ok;
		}
	
	
}
