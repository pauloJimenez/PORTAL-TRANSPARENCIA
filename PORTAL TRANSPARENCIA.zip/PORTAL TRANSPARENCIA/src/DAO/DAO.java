package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import modelo.despesaPublica;

public class DAO {

	public Connection getConnection(){
		
		Connection conecta = null;
		
		try{
			
		String url =  "jdbc:sqlserver://nemesis:1433;databaseName=Fluig_Teste;user=username;password=password";
		
	    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				
	    conecta =  DriverManager.getConnection(url);								
		
		}
		catch(ClassNotFoundException ex1){
			
			ex1.printStackTrace();
			
		}
		catch (SQLException ex)
	    {
	        
	        ex.printStackTrace();
	    }
		return conecta;
	}
	
	public void  criadespesa(despesaPublica despesa){
		
		Connection conectado = getConnection();
		
		String sql = "INSERT INTO  DESPESA_PUBLICA ";
		       sql+= "( codigoFavorecido, data, documento, documentoResumido, especie, fase, favorecido, favorecidoIntermediario, localizadorGasto, nomeFavorecido, orgao, orgaoSuperior, subtitulo, ufFavorecido, ug, valor )";
		       sql+= "values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		try {
			
			PreparedStatement stmt = conectado.prepareStatement(sql);
			                  stmt.setString(1, despesa.getCodigoFavorecido());
			                  stmt.setString(2, despesa.getData());
			                  stmt.setString(3, despesa.getDocumento());
			                  stmt.setString(4, despesa.getDocumentoResumido());
			                  stmt.setString(5, despesa.getEspecie());
			                  stmt.setString(6, despesa.getFase());
			                  stmt.setString(7, despesa.getFavorecido());
			                  stmt.setString(8, despesa.getFavorecidoIntermediario());
			                  stmt.setString(9, despesa.getLocalizadorGasto());
			                  stmt.setString(10, despesa.getNomeFavorecido());
			                  stmt.setString(11, despesa.getOrgao());
			                  stmt.setString(12, despesa.getOrgaoSuperior());
			                  stmt.setString(13, despesa.getSubtitulo());
			                  stmt.setString(14, despesa.getUfFavorecido());
			                  stmt.setString(15, despesa.getUg());
			                  stmt.setString(16, despesa.getValor());
			
			                  stmt.execute();
			                  stmt.close();
			                  conectado.close();
			                  
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

	}
	
	
}
