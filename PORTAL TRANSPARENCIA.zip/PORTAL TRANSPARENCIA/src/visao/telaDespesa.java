package visao;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controle.cliente;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import modelo.despesaPublica;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class telaDespesa extends JFrame {

	private JPanel contentPane;
	private JTextField unidG;
	private JTextField dtEmissao;
	private JTextField fase;
	private JTextField pagina;
	private JButton btnNewButton;
	private JLabel lblGestao;
	private JTextField gestao;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					telaDespesa frame = new telaDespesa();
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public telaDespesa() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1071, 73);
		contentPane = new JPanel();
		setTitle("Despesas P�blicas");
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setResizable(false);
		
		JLabel lblUnidadeGestora = new JLabel("Unidade Gestora");
		contentPane.add(lblUnidadeGestora, "2, 2, right, default");
		
		unidG = new JTextField();
		contentPane.add(unidG, "4, 2, fill, default");
		unidG.setColumns(10);
		
		lblGestao = new JLabel("Gestao");
		contentPane.add(lblGestao);
		
		gestao = new JTextField();
		contentPane.add(gestao);
		gestao.setColumns(10);
		
		JLabel lblDataEmisso = new JLabel("Data Emiss\u00E3o");
		contentPane.add(lblDataEmisso, "2, 4, right, default");
		
		dtEmissao = new JTextField();
		contentPane.add(dtEmissao, "4, 4, fill, default");
		dtEmissao.setColumns(10);
		
		JLabel lblFase = new JLabel("Fase");
		contentPane.add(lblFase, "2, 6, right, default");
		
		fase = new JTextField();
		contentPane.add(fase, "4, 6, fill, default");
		fase.setColumns(10);
		
		JLabel lblPgina = new JLabel("P\u00E1gina");
		contentPane.add(lblPgina, "2, 8, right, default");
		
		pagina = new JTextField();
		contentPane.add(pagina, "4, 8, fill, default");
		pagina.setColumns(10);
		pagina.setToolTipText("Para executar com todas as paginas, informar 0");					
		
		btnNewButton = new JButton("Executar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
										
				//if (!unidG.getText().equals("") && !dtEmissao.getText().equals("") && !fase.getText().equals("") && !pagina.getText().equals("")){
				if(!dtEmissao.getText().equals("") && !fase.getText().equals("") && !pagina.getText().equals("")){
				
					if (!unidG.getText().equals("") || !gestao.getText().equals("")){
						
						if(pagina.getText().equals("0")){
							
							boolean ok = false; 
							
							for (int i = 1; i <= 99; i++) {
								
								cliente cli = new cliente();
								
								   ok = cli.executaAll(unidG.getText(),dtEmissao.getText(),fase.getText(),String.valueOf(i),gestao.getText());
								       
								if(ok == false) break;
								
							}
							JOptionPane.showMessageDialog(null, "Executado com sucesso");
						}
						else{
							
							boolean ok = false; 
							
							cliente cli = new cliente();
						      
							despesaPublica desp = new despesaPublica();
							
						      ok =  cli.executa(unidG.getText(),dtEmissao.getText(),fase.getText(),pagina.getText(),gestao.getText(),desp);
						        
						      if(ok == false){
						    	  if(desp.getRetorno().equals("OK")){JOptionPane.showMessageDialog(null,"N�o existe despesa para esta consulta");}
						    	  else {JOptionPane.showMessageDialog(null,desp.getRetorno());}
						      }
						      else{
						    	  JOptionPane.showMessageDialog(null, "Executado com sucesso");
						      }
						}
					}
					else{JOptionPane.showMessageDialog(null, "Deve ser preenchido ao menos o filtro de unidade gestora ou gest�o");}
				}
				else {JOptionPane.showMessageDialog(null,"Deve ser preenchido os campos obrigat�rios data de emiss�o,fase, p�gina e ao menos o filtro unidade gestora ou gest�o","Preenchimento obrigat�rio",JOptionPane.WARNING_MESSAGE);}
			}
		});
				
		contentPane.add(btnNewButton, "4, 10");
	}

}
