package modelo;

public class despesaPublica {

	String codigoFavorecido;
	String data;
	String documento;
	String documentoResumido; 
	String especie; 
	String fase; 
	String favorecido;	
	String favorecidoIntermediario;
	String localizadorGasto;
	String nomeFavorecido;
	String orgao;
	String orgaoSuperior;
	String subtitulo;
	String ufFavorecido;
	String ug;
	String valor;
	String retorno;
	
	public String getCodigoFavorecido() {
		return codigoFavorecido;
	}
	public void setCodigoFavorecido(String codigoFavorecido) {
		this.codigoFavorecido = codigoFavorecido;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getDocumento() {
		return documento;
	}
	public void setDocumento(String documento) {
		this.documento = documento;
	}
	public String getDocumentoResumido() {
		return documentoResumido;
	}
	public void setDocumentoResumido(String documentoResumido) {
		this.documentoResumido = documentoResumido;
	}
	public String getEspecie() {
		return especie;
	}
	public void setEspecie(String especie) {
		this.especie = especie;
	}
	public String getFase() {
		return fase;
	}
	public void setFase(String fase) {
		this.fase = fase;
	}
	public String getFavorecido() {
		return favorecido;
	}
	public void setFavorecido(String favorecido) {
		this.favorecido = favorecido;
	}
	public String getFavorecidoIntermediario() {
		return favorecidoIntermediario;
	}
	public void setFavorecidoIntermediario(String favorecidoIntermediario) {
		this.favorecidoIntermediario = favorecidoIntermediario;
	}
	public String getLocalizadorGasto() {
		return localizadorGasto;
	}
	public void setLocalizadorGasto(String localizadorGasto) {
		this.localizadorGasto = localizadorGasto;
	}
	public String getNomeFavorecido() {
		return nomeFavorecido;
	}
	public void setNomeFavorecido(String nomeFavorecido) {
		this.nomeFavorecido = nomeFavorecido;
	}
	public String getOrgao() {
		return orgao;
	}
	public void setOrgao(String orgao) {
		this.orgao = orgao;
	}
	public String getOrgaoSuperior() {
		return orgaoSuperior;
	}
	public void setOrgaoSuperior(String orgaoSuperior) {
		this.orgaoSuperior = orgaoSuperior;
	}
	public String getSubtitulo() {
		return subtitulo;
	}
	public void setSubtitulo(String subtitulo) {
		this.subtitulo = subtitulo;
	}
	public String getUfFavorecido() {
		return ufFavorecido;
	}
	public void setUfFavorecido(String ufFavorecido) {
		this.ufFavorecido = ufFavorecido;
	}
	public String getUg() {
		return ug;
	}
	public void setUg(String ug) {
		this.ug = ug;
	}
	public String getValor() {
		return valor;
	}
	public void setValor(String valor) {
		this.valor = valor;
	}
	public String getRetorno() {
		return retorno;
	}
	public void setRetorno(String retorno) {
		this.retorno = retorno;
	}
	
	
	
	
}
